/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jiajia
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setName method, of class Student.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String inName = "testSet";
        Student instance = new Student();
        instance.setName(inName);
        assertEquals(instance.name,inName);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Student.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Student instance = new Student();
        instance.setName("testGet");
        String expResult = "testGet";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setNSID method, of class Student.
     */
    @Test
    public void testSetNSID() {
        System.out.println("setNSID");
        String inNSID = "setNSID";
        Student instance = new Student();
        instance.setNSID(inNSID);
        assertEquals(instance.NSID,inNSID);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNSID method, of class Student.
     */
    @Test
    public void testGetNSID() {
        System.out.println("getNSID");
        Student instance = new Student();
        instance.setNSID("getNSID");
        String expResult = "getNSID";
        String result = instance.getNSID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of outputStudent method, of class Student.
     */
    @Test
    public void testOutputStudent() {
        System.out.println("outputStudent");
        Student instance = new Student();
        instance.setNSID("NSID");
        instance.setName("Name");
        String expResult = "NSID, Name";
        String result = instance.outputStudent();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of compareTo method, of class Student.
     */
    @Test
    public void testCompareTo() {
        System.out.println("compareTo");
        Student otherObject = new Student();
        otherObject.setNSID("abc123");
        Student instance = new Student();
        instance.setNSID("acc123");
        int expResult = 1;
        int result = instance.compareTo(otherObject);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

}

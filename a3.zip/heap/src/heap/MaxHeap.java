/*
 * Name: Huang Jiaming
 * NSID: jih211
 * StuID: 11207964
 */
package heap;
/**
 *
 * @author jiajia
 * @param <T>
 */
public class MaxHeap<T extends Comparable<T>> {

    BTree<T> elements;
    
    public MaxHeap() {
        elements = new BTree();
    }
/*
 *Pre: a Heap is constructed
 *Post: a new element is added to the heap keeping the maxHeap property
 */    
    public void add(T newElement) {
        int num = this.elements.getSum();
        this.elements.insert(newElement,num);
        fixHeap();
    }
/*
 *Pre:a maxHeap
 *Post: the top element is returned and the original maxHeap remains unchanged
 */    
    public T peak() {
        Student aa = new Student();
        T output = (T)aa;
        if(!empty()){
            String oNSID = ((Student)elements.elem).getNSID();
            String oName = ((Student)elements.elem).getName();
            aa.setNSID(oNSID);
            aa.setName(oName);
        }
        return output;
    }
/*
 *Pre:a maxHeap
 *Post: the top element is removed and returned and the remaining maxHeap keeps its property
 */    
    public T remove() {
        Student aa = new Student();
        T output = (T)aa;
        if(!empty()){
            String oNSID = ((Student)elements.elem).getNSID();
            String oName = ((Student)elements.elem).getName();
            aa.setNSID(oNSID);
            aa.setName(oName);
            
            elements.remove();
            fixHeap();
        }
        return output;
    }
/*
 *Pre:a maxHeap with its top element removed
 *Post: the maxHeap is fixed to keep the property of maxHeap
 */    
    private void fixHeap() {
        if (!elements.getFlag())
            elements.fixTop();
        else
            elements.fixDown();
    }
/*
 *Pre:a maxHeap
 *Post: check if it's empty, maxHeap remains unchanged
 */    
    public Boolean empty() {
        return (elements.getSum() == 0);
    }
/*
 *Pre:a maxHeap
 *Post: return leftChild, maxHeap remains unchanged
 */    
    private BTree<T> getLeftChild(BTree<T> rootOfTree) {
        return rootOfTree.leftBTree;
    }
/*
 *Pre:a maxHeap
 *Post: return rightChild, maxHeap remains unchanged
 */    
    private BTree<T> getRightChild(BTree<T> rootOfTree) {
        return rootOfTree.rightBTree;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        MaxHeap<Student> nHeap = new MaxHeap<>();
        nHeap.add(a);
        nHeap.add(b);
        nHeap.add(c);
        nHeap.add(d);
        Student out = nHeap.peak();
        Student out1 = nHeap.remove();
        Student out2 = nHeap.remove();
        System.out.println(nHeap.empty());
        Student out3 = nHeap.remove();
        System.out.println(nHeap.empty());
        Student out4 = nHeap.remove();
        Student outEmpty = nHeap.remove();
        System.out.println(nHeap.empty());
    }
    
}

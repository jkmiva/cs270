/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jiajia
 */
public class BTreeTest {
    
    public BTreeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of insertion method, of class BTree.
     */
    @Test
    public void testInsertion() {
        System.out.println("insertion");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        int num = 0;
        BTree instance = new BTree();
        instance.insertion(a, num);
        num++;
        instance.insertion(b, num);
        num++;
        instance.insertion(c, num);
        num++;
        instance.insertion(d, num);
//test if it is Breadth-first Insertion!!
// Level 1
        String exp1 = "cmc133, Cyril";
        String res1 = ((Student)instance.elem).outputStudent();
        assertEquals(exp1,res1);
// Level 2
        String exp2 = "kjb455, Kel";
        String res2 = ((Student)instance.leftBTree.elem).outputStudent();
        assertEquals(exp2,res2);
        String exp3 = "pfr566, Peter";
        String res3 = ((Student)instance.rightBTree.elem).outputStudent();
        assertEquals(exp3,res3);
// Level 3
        String exp4 = "jks771, Joan";
        String res4 = ((Student)instance.leftBTree.leftBTree.elem).outputStudent();
        assertEquals(exp4,res4);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setElem method, of class BTree.
     */
    @Test
    public void testSetElem() {
        System.out.println("setElem");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        BTree instance = new BTree();
        instance.setElem(a);
        String exp = a.outputStudent();
        String res = ((Student)instance.elem).outputStudent();
        assertEquals(exp,res);        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSum method, of class BTree.
     */
    @Test
    public void testGetSum() {
        System.out.println("getSum");
        BTree instance = new BTree();
        int expResult = 0;
        int result = instance.getSum();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFlag method, of class BTree.
     */
    @Test
    public void testGetFlag() {
        System.out.println("getFlag");
        BTree instance = new BTree();
        boolean expResult = true;
        boolean result = instance.getFlag();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of insert method, of class BTree.
     */
    @Test
    public void testInsert() {
        System.out.println("insert");
// regression test for insertion()        
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        int num = 0;
        BTree instance = new BTree();
        instance.insert(a, num);
        num++;
        instance.insert(b, num);
        num++;
        instance.insert(c, num);
        num++;
        instance.insert(d, num);
//test if it is Breadth-first Insertion!!
// Level 1
        String exp1 = "cmc133, Cyril";
        String res1 = ((Student)instance.elem).outputStudent();
        assertEquals(exp1,res1);
// Level 2
        String exp2 = "kjb455, Kel";
        String res2 = ((Student)instance.leftBTree.elem).outputStudent();
        assertEquals(exp2,res2);
        String exp3 = "pfr566, Peter";
        String res3 = ((Student)instance.rightBTree.elem).outputStudent();
        assertEquals(exp3,res3);
// Level 3
        String exp4 = "jks771, Joan";
        String res4 = ((Student)instance.leftBTree.leftBTree.elem).outputStudent();
        assertEquals(exp4,res4);
        
// test sum and flag        
        assertEquals(instance.sum,4);
        assertEquals(instance.flag,true);
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of fixDown method, of class BTree.
     */
    @Test
    public void testFixDown() {
        System.out.println("fixDown");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        BTree instance = new BTree();
        instance.insert(a, 0);
        instance.fixDown();
        instance.insert(b, 1);
        instance.fixDown();
        instance.insert(c, 2);
        instance.fixDown();
        instance.insert(d, 3);
        instance.fixDown();
        
        String exp = "pfr566, Peter";
        String res = ((Student)instance.elem).outputStudent();
        assertEquals(exp,res);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of swapDownTop method, of class BTree.
     */
    @Test
    public void testSwapDownTop() {
        System.out.println("swapDownTop");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        int p = 1;
        int c = 2;
        BTree instance = new BTree();
        instance.insert(a, 0);
        instance.insert(b, 1);
        instance.swapDownTop(p, c);
        String exp = "kjb455, Kel";
        String res = a.outputStudent();
        assertEquals(exp,res);
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of swap2Student method, of class BTree.
     */
    @Test
    public void testSwap2Student() {
        System.out.println("swap2Student");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        BTree instance = new BTree();
        instance.swap2Student(a, b);
        String exp = "kjb455, Kel";
        String res = a.outputStudent();
        assertEquals(exp,res);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of fixTop method, of class BTree.
     */
    @Test
    public void testFixTop() {
        System.out.println("fixTop");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        BTree instance = new BTree();
        instance.insert(a, 0);
        instance.fixDown();
        instance.insert(b, 1);
        instance.fixDown();
        instance.insert(c, 2);
        instance.fixDown();
        instance.insert(d, 3);
        instance.fixDown();
// right here, peak of instance is Student c        
        
        instance.remove();
        instance.fixTop();
        
        String exp = "kjb455, Kel";
        String res = ((Student)instance.elem).outputStudent();
        assertEquals(exp,res);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of replaceTop method, of class BTree.
     */
    @Test
    public void testReplaceTop() {
        System.out.println("replaceTop");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        BTree instance = new BTree();
        instance.insert(a, 0);
        instance.fixDown();
        instance.insert(b, 1);
        instance.fixDown();
        instance.insert(c, 2);
        instance.fixDown();
        instance.insert(d, 3);
        instance.fixDown();
// right here, peak of instance is Student c        
        int p = 2;
        int cc = 4;
        Student peak = (Student)instance.elem;
        instance.replaceTop(p, cc, peak);
        String exp = "cmc133, Cyril";
        String res = ((Student)instance.elem).outputStudent();
        assertEquals(exp,res);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of remove method, of class BTree.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
// regression test for replaceTop()        
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        BTree instance = new BTree();
        instance.insert(a, 0);
        instance.fixDown();
        instance.insert(b, 1);
        instance.fixDown();
        instance.insert(c, 2);
        instance.fixDown();
        instance.insert(d, 3);
        instance.fixDown();
// right here, peak of instance is Student c        
        
        instance.remove();
        String exp = "cmc133, Cyril";
        String res = ((Student)instance.elem).outputStudent();
        assertEquals(exp,res);
// test sum and flag
        assertEquals(instance.sum,3);
        assertEquals(instance.flag,false);
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
}

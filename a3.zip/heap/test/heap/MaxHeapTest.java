/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jiajia
 */
public class MaxHeapTest {
    
    public MaxHeapTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of add method, of class MaxHeap.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        MaxHeap<Student> nHeap = new MaxHeap<>();
        nHeap.add(a);
        nHeap.add(b);
        nHeap.add(c);
        nHeap.add(d);
        
        String exp = "pfr566, Peter";
        String res = ((Student)nHeap.elements.elem).outputStudent();
        assertEquals(exp,res);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of peak method, of class MaxHeap.
     */
    @Test
    public void testPeak() {
        System.out.println("peak");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        MaxHeap<Student> nHeap = new MaxHeap<>();
        nHeap.add(a);
        nHeap.add(b);
        nHeap.add(c);
        nHeap.add(d);
        String expResult = "pfr566, Peter";
        Student out = nHeap.peak();
        String result = out.outputStudent();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of remove method, of class MaxHeap.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        Student b = new Student();
        b.setNSID("kjb455");
        b.setName("Kel");
        Student c = new Student();
        c.setNSID("pfr566");
        c.setName("Peter");
        Student d = new Student();
        d.setNSID("jks771");
        d.setName("Joan");
        MaxHeap<Student> nHeap = new MaxHeap<>();
        nHeap.add(a);
        nHeap.add(b);
        nHeap.add(c);
        nHeap.add(d);
        Student out = nHeap.remove();
        String exp1 = "pfr566, Peter";
        String res1 = out.outputStudent();
        String exp2 = "kjb455, Kel";
        String res2 = ((Student)nHeap.elements.elem).outputStudent();
        assertEquals(exp1,res1);
        assertEquals(exp2,res2);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of empty method, of class MaxHeap.
     */
    @Test
    public void testEmpty() {
        System.out.println("empty");
        MaxHeap instance = new MaxHeap();
        Boolean exp1 = true;
        Boolean res1 = instance.empty();
        assertEquals(exp1, res1);
        Student a = new Student();
        a.setNSID("cmc133");
        a.setName("Cyril");
        instance.add(a);
        Boolean exp2 = false;
        Boolean res2 = instance.empty();
        assertEquals(exp2, res2);
        instance.remove();
        Boolean exp3 = true;
        Boolean res3 = instance.empty();
        assertEquals(exp3, res3);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
}

/*
 * Name: Huang Jiaming
 * NSID: jih211
 * StuID: 11207964
 */
package heap;
/**
 *
 * @author jiajia
 * @param <T>
 */
public class BTree<T extends Comparable<T>> {
    T elem;
    BTree<T> leftBTree;
    BTree<T> rightBTree;
    int sum = 0;
    boolean flag = true; // fixDown or fixTop
    
    public BTree(){
    }
    public BTree(T element){
        elem = element;
        sum++;
    }
// width first insert    
    public void insertion(T inElement, int num) {
        if (this.elem == null)           
            setElem(inElement);
        else{
            int parent = (num-1)/2;
            if (parent == 0){
                if (this.leftBTree == null){
                    BTree inBTree = new BTree(inElement);
                    this.leftBTree = inBTree;       
                }
                else{
                    BTree inBTree = new BTree(inElement);
                    this.rightBTree = inBTree;                    
                }
            }
            else{
                if((parent%2)==1)
                    this.leftBTree.insertion(inElement,parent);
                else
                    this.rightBTree.insertion(inElement, parent);
            }
        }
    }
 
    public void setElem(T inElement) {
        this.elem = inElement;
    }
    
    public int getSum() {
        return sum;
    }
    
    public boolean getFlag() {
        return flag;
    }
//fix after insertion
    public void insert(T inElement, int num) {
        insertion(inElement, num);
        (this.sum)++;
        flag = true;
    }

    public void fixDown() {
        int child = this.getSum();
        while (child > 1) {
            int parent = child/2;
            swapDownTop(parent,child);
            child = parent;
        }
    }
    
    public void swapDownTop(int p, int c) {
        int parent = p/2;
        if (parent == 0){
            if(c%2 == 1)
                swap2Student(this.elem, this.rightBTree.elem);
            else
                swap2Student(this.elem, this.leftBTree.elem);
        }
        else{
            if((p%2)==1)
                this.rightBTree.swapDownTop(parent, c);
            else
                this.leftBTree.swapDownTop(parent, c);
        }
    }
    
    public void swap2Student(T a, T b){
        if (a.compareTo(b) < 0) {
            String aNSID = ((Student)a).getNSID();
            String aName = ((Student)a).getName();
            ((Student)a).setNSID(((Student)b).getNSID());
            ((Student)a).setName(((Student)b).getName());
            ((Student)b).setNSID(aNSID);
            ((Student)b).setName(aName);
        }
    }
    
// fix after remove
    
    
    public void fixTop() {
        if (this.rightBTree != null){
            T left = this.leftBTree.elem;
            T right = this.rightBTree.elem;
            if (left.compareTo(right) < 0) {
                swap2Student(this.elem, this.rightBTree.elem);
                this.rightBTree.fixTop();
            }
            else{
                swap2Student(this.elem, this.leftBTree.elem);
                this.leftBTree.fixTop();
            }
        }
        else{
            if (this.leftBTree != null){
                swap2Student(this.elem, this.leftBTree.elem);
            }
        }
    }
    
//replace peek with last elements
    public void replaceTop(int p, int c, T peak) {
        int parent = p/2;
        if (parent == 0){
            if(c%2 == 1){
                //replace peak with rightBtree and remove rightBtree
                swap2Student(this.rightBTree.elem, peak);
                this.rightBTree = null;               
            }
            else{
                // replace peak with leftBtree and remove leftBTree
                swap2Student(this.leftBTree.elem, peak);
                this.leftBTree = null;
            }
                
        }
        else{
            if((p%2)==1)
                this.rightBTree.replaceTop(parent, c, peak);
            else
                this.leftBTree.replaceTop(parent, c, peak);
        }
    }
// remove top
    public void remove(){
        int child = this.getSum();
        if (child == 1) {
            this.elem = null;
            (this.sum)--;
            return;
        }
        replaceTop(child/2, child, this.elem);
        (this.sum)--;
        flag = false;        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}

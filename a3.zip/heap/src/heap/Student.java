/*
 * Name: Huang Jiaming
 * NSID: jih211
 * StuID: 11207964
 */
package heap;
/**
 *
 * @author jiajia
 */
public class Student implements Comparable<Student> {
    String name;
    String NSID;
    
    public void setName(String inName) {
        this.name = inName;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setNSID(String inNSID) {
        this.NSID = inNSID;
    }
    
    public String getNSID() {
        return this.NSID;
    }
    
    public String outputStudent() {    
        return this.NSID.concat(", ").concat(this.name);
    }
    
    @Override
    public int compareTo(Student otherObject) {
        if (this.NSID.compareTo(otherObject.NSID) > 0)
            return 1;
        else if(this.NSID.compareTo(otherObject.NSID) < 0){
            return -1;
        }
        else
            return 0;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
